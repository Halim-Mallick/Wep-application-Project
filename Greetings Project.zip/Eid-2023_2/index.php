<!DOCTYPE html>
<html>
<head>
    <title>Greeting Message</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Play&display=swap');
    </style>
</head>
<body>
    <div class="container">
        <h1>Birthday Greetings!</h1>
        <p id="Main-message">You can wish your friend by your name.</p>
        <button onclick="YourName()">Enter Your Name</button>
        <button onclick="FrndName()">Enter Friend Name</button>
    </div>

    <script src="script.js"></script>
</body>
</html>
